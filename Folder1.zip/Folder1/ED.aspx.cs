﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Fighter
{
    public partial class ED : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtID.Text !="" && txtName.Text != "" && txtAge.Text != "" && txtHeight.Text != "" && txtWeight.Text != "" && txtReach.Text != "" && txtWin.Text != "" && txtLoss.Text != "" && txtDraw.Text != "" && ddlOrg.Text != "")
            {
                // Defines a connection to database
                OleDbConnection conn = new OleDbConnection("PROVIDER=Microsoft.ACE.OLEDB.12.0; Data Source=" +
                    HostingEnvironment.MapPath(@"/App_Data/") +
                    "FighterDB.accdb; Persist Security Info=False;");
                conn.Open();
                OleDbCommand command = conn.CreateCommand();
                string strSQL;
                strSQL = "Update Fighter " +
                    "Set Name ='" + txtName.Text + "', Age ='" + txtAge.Text + "', Height ='" + txtHeight.Text + "', Weight ='" + txtWeight.Text + "', Reach ='" + txtReach.Text + "', Win ='" + txtWin.Text + "', Loss ='" + txtLoss.Text + "', Draw ='" + txtDraw.Text + "', Organization ='" + ddlOrg.Text + "' " +
                    "Where ID = " + Convert.ToInt32(txtID.Text) ;
                command.CommandType = CommandType.Text;
                command.CommandText = strSQL;
                command.ExecuteNonQuery();
                conn.Close();
                lblStatusBar.Text = "Data Updated!";
            }
            else
            {
                lblStatusBar.Text = "Please enter mandatory details!";
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtID.Text = null;
            txtName.Text = null;
            txtAge.Text = null;
            txtHeight.Text = null;
            txtWeight.Text = null;
            txtReach.Text = null;
            txtWin.Text = null;
            txtLoss.Text = null;
            txtDraw.Text = null;
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtID.Text != "")
            {
                // Defines a connection to database
                OleDbConnection conn = new OleDbConnection("PROVIDER=Microsoft.ACE.OLEDB.12.0; Data Source=" +
                    HostingEnvironment.MapPath(@"/App_Data/") +
                    "FighterDB.accdb; Persist Security Info=False;");
                conn.Open();
                OleDbCommand command = conn.CreateCommand();
                string strSQL;
                strSQL = "Delete From Fighter Where ID =" + Convert.ToInt32(txtID.Text);
                command.CommandType = CommandType.Text;
                command.CommandText = strSQL;
                command.ExecuteNonQuery();
                conn.Close();
                lblStatusBar.Text = "Data Updated!";
            }
            else
            {
                lblStatusBar.Text = "Please enter mandatory details!";
            }
        }
    }
}