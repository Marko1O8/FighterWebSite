﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Fighter
{
    public partial class View : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnOrg_Click(object sender, EventArgs e)
        {
            try
            {
                Org.FilterExpression = ddlOrg.Text + " like '%" + txtOrg.Text + "%'";
                lblStatusOrg.Text = "Found all occurances of " + txtOrg.Text;

            }
            catch
            {
                lblStatusOrg.Text = "No occurances for " + txtOrg.Text;
            }
            finally
            {

            }
        }

        protected void btnFighter_Click(object sender, EventArgs e)
        {
            try
            {
                Fighter.FilterExpression = "Name like '%" + txtFighter.Text + "%'";
                lblStatusFighter.Text = "Found all occurances of " + txtFighter.Text;

            }
            catch
            {
                lblStatusFighter.Text = "No occurances for " + txtFighter.Text;
            }
            finally
            {

            }
        }
    }
}