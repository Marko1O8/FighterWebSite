﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Fighter
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void txtID_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text != "" && txtID.Text != "")
            {
                // Defines a connection to database
                OleDbConnection conn = new OleDbConnection("PROVIDER=Microsoft.ACE.OLEDB.12.0; Data Source=" +
                    HostingEnvironment.MapPath(@"/App_Data/") +
                    "FighterDB.accdb; Persist Security Info=False;");
                conn.Open();
                string strSQL = "Select Count(*) from Login Where UserID=? and [Password] =?";
                OleDbCommand cmd = new OleDbCommand(strSQL, conn);
                cmd.Parameters.AddWithValue("@p1", txtID.Text);
                cmd.Parameters.AddWithValue("@p2", txtPassword.Text);  // <- is this a variable or a textbox?

                int result = (int)cmd.ExecuteScalar();
                conn.Close();

                if (result > 0)
                {
                    // Success - Redirect to Home Page
                    Response.Redirect("Default.aspx");
                }
                else
                {
                    // Fail - Display message
                    lblStatus.Text = "Invalid Login please check username and password";
                }
            }
            else
            {
                lblStatus.Text = "Please enter the user name and password!";
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtID.Text = null;
            txtPassword.Text = null;
        }
    }
}