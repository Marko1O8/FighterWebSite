﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Fighter
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtName.Text = null;
            txtAge.Text = null;
            txtHeight.Text = null;
            txtWeight.Text = null;
            txtReach.Text = null;
            txtWin.Text = null;
            txtLoss.Text = null;
            txtDraw.Text = null;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "" && txtAge.Text != "" && txtHeight.Text != "" && txtWeight.Text != "" && txtReach.Text != "" && txtWin.Text != "" && txtLoss.Text != "" && txtDraw.Text != "" && ddlOrg.Text != "")
            {
                // Defines a connection to database
                OleDbConnection conn = new OleDbConnection("PROVIDER=Microsoft.ACE.OLEDB.12.0; Data Source=" +
                    HostingEnvironment.MapPath(@"/App_Data/") +
                    "FighterDB.accdb; Persist Security Info=False;");
                conn.Open();
                OleDbCommand command = conn.CreateCommand();
                string strSQL;
                strSQL = "Insert into Fighter (Name, Age, Height, Weight, Reach, Win, Loss, Draw, Organization) values ('" +
                    txtName.Text + "', '" + txtAge.Text + "', '" + txtHeight.Text + "', '" + txtWeight.Text + "', '" + txtReach.Text + "', '" + txtWin.Text + "', '" + txtLoss.Text + "', '" + txtDraw.Text + "', '" + ddlOrg.Text + "')";
                command.CommandType = CommandType.Text;
                command.CommandText = strSQL;
                command.ExecuteNonQuery();
                conn.Close();
                lblStatus.Text = "Data added!";
            }
            else
            {
                lblStatus.Text = "Please enter mandatory details!";
            }
        }
    }
}